public class OrderTest {
   

   public static void main(String[] args) {

      Items item1 = new Items("Drip", 2.2);
      Items item2 = new Items("Capuccino", 1.2);
      Items item3 = new Items("Mocha", 2.5);
      Items item4 = new Items("Latte", 3.7);


      Orders order1 = new Orders();
      Orders order2 = new Orders();

      Orders order3= new Orders("Lauren");
      Orders order4 = new Orders("Bandit");
      Orders order5 = new Orders("Parker");


      order1.addItem(item1);
      order1.addItem(item2);

      order2.addItem(item1);
      order2.addItem(item1);


      order3.addItem(item4);
      order3.addItem(item3);



      order4.addItem(item4);
      order4.addItem(item4);



      order5.addItem(item2);
      order5.addItem(item3);


      order1.display();
      order2.display();
      order3.display();
      order4.display();
      order5.display();


      order1.setReady(true);
      System.out.println(order2.getStatusMessage());

      order1.getOrderTotal();
      System.out.println(order2.getOrderTotal());
   }

}
